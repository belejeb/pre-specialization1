<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Ingrese los datos del usuario</h1>

 <form action="INSERTARNivel.php" method="post">

   <label for="usuario">Nombre Nivel:</label>
   <input type="text" name="nivel" value="" autocomplete="off" placeholder="admin"><br><br>
   <input type="submit" name="guardar" value="Guardar">
 </form>
  </body>
</html>
