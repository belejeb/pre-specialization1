<?php

$con  = new mysqli("localhost","root","","dbfarmacia");

?>
